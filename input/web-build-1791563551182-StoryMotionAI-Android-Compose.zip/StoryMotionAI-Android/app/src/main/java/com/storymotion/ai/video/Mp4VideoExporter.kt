package com.storymotion.ai.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Environment
import android.util.Log
import com.storymotion.ai.data.models.CameraMotion
import com.storymotion.ai.data.models.StoryProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class Mp4VideoExporter(private val context: Context) {

    suspend fun exportProjectToMp4(
        project: StoryProject,
        onProgress: (percent: Int, status: String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val width = if (project.isPortrait) 720 else 1280
            val height = if (project.isPortrait) 1280 else 720
            val frameRate = 30
            val bitRate = 4_000_000

            val outputDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
            val outputFile = File(outputDir, "StoryMotion_${System.currentTimeMillis()}.mp4")

            onProgress(5, "Configuring H.264 Video Encoder...")

            // MediaFormat setup
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
                setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val inputSurface = encoder.createInputSurface()
            encoder.start()

            val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var videoTrackIndex = -1
            var isMuxerStarted = false

            val bufferInfo = MediaCodec.BufferInfo()
            val totalScenes = project.scenes.size
            var currentFrame = 0L

            // Render scenes onto Surface Canvas
            for ((sceneIndex, scene) in project.scenes.withIndex()) {
                val sceneFrames = (scene.durationSec * frameRate).toInt()
                val currentDialogue = scene.dialogues.firstOrNull()

                for (frame in 0 until sceneFrames) {
                    val progress = frame.toFloat() / sceneFrames
                    val canvas: Canvas = inputSurface.lockHardwareCanvas()

                    // 1. Draw Environmental Backdrop
                    drawSceneBackdrop(canvas, scene.backdropColorHex, width, height, progress)

                    // 2. Apply Camera Motion
                    applyMotionTransform(canvas, scene.cameraMotion, progress, width, height)

                    // 3. Draw Character Cards
                    drawCharacters(canvas, project, scene, width, height)

                    // 4. Draw Subtitles
                    if (currentDialogue != null) {
                        drawSubtitles(canvas, currentDialogue.speakerName, currentDialogue.line, width, height)
                    }

                    inputSurface.unlockCanvasAndPost(canvas)

                    // Drain encoder output
                    while (true) {
                        val outputBufferId = encoder.dequeueOutputBuffer(bufferInfo, 0)
                        if (outputBufferId == MediaCodec.INFO_TRY_AGAIN_LATER) {
                            break
                        } else if (outputBufferId == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            videoTrackIndex = muxer.addTrack(encoder.outputFormat)
                            muxer.start()
                            isMuxerStarted = true
                        } else if (outputBufferId >= 0) {
                            val encodedData = encoder.getOutputBuffer(outputBufferId)
                            if (encodedData != null && isMuxerStarted) {
                                encodedData.position(bufferInfo.offset)
                                encodedData.limit(bufferInfo.offset + bufferInfo.size)
                                bufferInfo.presentationTimeUs = (currentFrame * 1_000_000L / frameRate)
                                muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                            }
                            encoder.releaseOutputBuffer(outputBufferId, false)
                        }
                    }

                    currentFrame++
                }

                val overallPercent = 10 + (((sceneIndex + 1).toFloat() / totalScenes) * 85).toInt()
                onProgress(overallPercent, "Encoding Scene ${scene.sceneNumber} of $totalScenes...")
            }

            // Signal End of Stream
            encoder.signalEndOfInputStream()

            // Drain remaining frames
            var isEos = false
            while (!isEos) {
                val outputBufferId = encoder.dequeueOutputBuffer(bufferInfo, 10000)
                if (outputBufferId >= 0) {
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        isEos = true
                    }
                    if (bufferInfo.size != 0 && isMuxerStarted) {
                        val encodedData = encoder.getOutputBuffer(outputBufferId)
                        if (encodedData != null) {
                            muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                        }
                    }
                    encoder.releaseOutputBuffer(outputBufferId, false)
                } else if (outputBufferId == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    isEos = true
                }
            }

            encoder.stop()
            encoder.release()
            inputSurface.release()

            if (isMuxerStarted) {
                muxer.stop()
            }
            muxer.release()

            onProgress(100, "Export complete! Saved to ${outputFile.name}")
            Result.success(outputFile)
        } catch (e: Exception) {
            Log.e("Mp4VideoExporter", "Export failed", e)
            Result.failure(e)
        }
    }

    private fun drawSceneBackdrop(canvas: Canvas, colorHex: String, width: Int, height: Int, progress: Float) {
        val paint = Paint()
        val baseColor = try { Color.parseColor(colorHex) } catch (e: Exception) { Color.parseColor("#1e1b4b") }

        paint.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            baseColor, Color.parseColor("#090d16"),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

        // Subtle horizon waves
        val wavePaint = Paint().apply {
            color = Color.parseColor("#330F172A")
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, height * 0.65f, width.toFloat(), height.toFloat(), wavePaint)
    }

    private fun applyMotionTransform(canvas: Canvas, motion: CameraMotion, progress: Float, width: Int, height: Int) {
        val cx = width / 2f
        val cy = height / 2f

        when (motion) {
            CameraMotion.ZOOM_IN -> {
                val scale = 1.0f + progress * 0.1f
                canvas.scale(scale, scale, cx, cy)
            }
            CameraMotion.ZOOM_OUT -> {
                val scale = 1.1f - progress * 0.1f
                canvas.scale(scale, scale, cx, cy)
            }
            CameraMotion.PAN_RIGHT -> {
                val tx = (progress - 0.5f) * -40f
                canvas.translate(tx, 0f)
            }
            CameraMotion.PAN_LEFT -> {
                val tx = (progress - 0.5f) * 40f
                canvas.translate(tx, 0f)
            }
            CameraMotion.STATIC -> {}
        }
    }

    private fun drawCharacters(canvas: Canvas, project: StoryProject, scene: com.storymotion.ai.data.models.Scene, width: Int, height: Int) {
        val present = project.characters.filter { scene.characterIdsPresent.contains(it.id) }
        val count = present.size
        if (count == 0) return

        val paint = Paint().apply { isAntiAlias = true }

        present.forEachIndexed { index, char ->
            val posX = if (count == 1) width * 0.5f else if (index == 0) width * 0.3f else width * 0.7f
            val posY = height * 0.52f

            // Character Card Background
            val cardPaint = Paint().apply {
                color = Color.parseColor("#CC0F172A")
                style = Paint.Style.FILL
                isAntiAlias = true
            }
            val cardRect = RectF(posX - 80f, posY - 100f, posX + 80f, posY + 100f)
            canvas.drawRoundRect(cardRect, 20f, 20f, cardPaint)

            // Avatar circle with character color
            val avatarColor = try { Color.parseColor(char.avatarColorHex) } catch (e: Exception) { Color.parseColor("#6366f1") }
            paint.color = avatarColor
            canvas.drawCircle(posX, posY - 20f, 45f, paint)

            // Character Name text
            val textPaint = Paint().apply {
                color = Color.WHITE
                textSize = 20f
                textAlign = Paint.Align.CENTER
                isFakeBoldText = true
                isAntiAlias = true
            }
            canvas.drawText(char.name.take(12), posX, posY + 50f, textPaint)

            // Role badge
            val rolePaint = Paint().apply {
                color = Color.parseColor("#38BDF8")
                textSize = 14f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText(char.role.take(15), posX, posY + 75f, rolePaint)
        }
    }

    private fun drawSubtitles(canvas: Canvas, speaker: String, line: String, width: Int, height: Int) {
        val bgPaint = Paint().apply {
            color = Color.parseColor("#D90F172A")
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val boxWidth = width * 0.85f
        val boxHeight = 100f
        val boxX = (width - boxWidth) / 2f
        val boxY = height - boxHeight - 40f

        val rect = RectF(boxX, boxY, boxX + boxWidth, boxY + boxHeight)
        canvas.drawRoundRect(rect, 24f, 24f, bgPaint)

        // Speaker label
        val speakerPaint = Paint().apply {
            color = Color.parseColor("#38BDF8")
            textSize = 18f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("$speaker:", width / 2f, boxY + 35f, speakerPaint)

        // Subtitle line text
        val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = 22f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(line.take(45), width / 2f, boxY + 70f, textPaint)
    }
}
