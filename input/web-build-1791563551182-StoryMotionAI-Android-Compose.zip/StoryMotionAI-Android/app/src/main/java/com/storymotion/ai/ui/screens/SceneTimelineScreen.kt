package com.storymotion.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.storymotion.ai.data.models.CameraMotion
import com.storymotion.ai.data.models.Character
import com.storymotion.ai.data.models.Scene
import com.storymotion.ai.ui.theme.SecondaryCyan
import com.storymotion.ai.ui.theme.SurfaceCard

@Composable
fun SceneTimelineScreen(
    scenes: List<Scene>,
    characters: List<Character>,
    onUpdateScene: (Int, Scene) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Scene Timeline & Camera Motion",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "Fine-tune visual framing, camera pan/zoom animations, and character consistency for each scene.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.LightGray
        )

        if (scenes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No scenes yet. Go to 'Story Editor' and tap 'Auto-Split Scenes'.",
                    color = Color.Gray
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(scenes) { index, scene ->
                    SceneTimelineCard(
                        scene = scene,
                        characters = characters,
                        onUpdate = { updatedScene -> onUpdateScene(index, updatedScene) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SceneTimelineCard(
    scene: Scene,
    characters: List<Character>,
    onUpdate: (Scene) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Scene ${scene.sceneNumber}: ${scene.title}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                // Duration Chip
                Surface(
                    color = Color.DarkGray,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "${scene.durationSec.toInt()}s",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = SecondaryCyan
                    )
                }
            }

            // Setting / Visual Prompt
            Text(
                text = "Setting: ${scene.setting}",
                style = MaterialTheme.typography.bodySmall,
                color = Color.LightGray
            )

            // Camera Motion Selector
            Text(text = "Camera Animation:", style = MaterialTheme.typography.labelMedium, color = Color.White)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                CameraMotion.values().forEach { motion ->
                    FilterChip(
                        selected = scene.cameraMotion == motion,
                        onClick = { onUpdate(scene.copy(cameraMotion = motion)) },
                        label = { Text(motion.name.take(4)) }
                    )
                }
            }

            // Characters Present in this scene
            Text(text = "Characters On Stage:", style = MaterialTheme.typography.labelMedium, color = Color.White)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                characters.forEach { char ->
                    val isPresent = scene.characterIdsPresent.contains(char.id)
                    FilterChip(
                        selected = isPresent,
                        onClick = {
                            val updatedList = if (isPresent) {
                                scene.characterIdsPresent - char.id
                            } else {
                                scene.characterIdsPresent + char.id
                            }
                            onUpdate(scene.copy(characterIdsPresent = updatedList))
                        },
                        label = { Text(char.name.take(8)) }
                    )
                }
            }
        }
    }
}
