package com.storymotion.ai.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.storymotion.ai.data.models.Character
import com.storymotion.ai.data.models.VoiceLanguage
import java.io.File
import java.util.Locale

class StoryTtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val bengaliLocale = Locale("bn", "IN")
    private val hindiLocale = Locale("hi", "IN")
    private val englishLocale = Locale.US

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            Log.d("StoryTtsManager", "TextToSpeech initialized successfully")
        } else {
            Log.e("StoryTtsManager", "Failed to initialize TextToSpeech: status=$status")
        }
    }

    fun speak(
        text: String,
        character: Character?,
        onDone: () -> Unit = {}
    ) {
        if (!isInitialized || tts == null) {
            onDone()
            return
        }

        val targetLocale = when (character?.voiceLanguage) {
            VoiceLanguage.BENGALI -> bengaliLocale
            VoiceLanguage.HINDI -> hindiLocale
            VoiceLanguage.ENGLISH -> englishLocale
            null -> englishLocale
        }

        tts?.let { engine ->
            val langResult = engine.setLanguage(targetLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to default or English if language data is missing
                engine.setLanguage(Locale.getDefault())
            }

            engine.setPitch(character?.pitch ?: 1.0f)
            engine.setSpeechRate(character?.speed ?: 1.0f)

            val utteranceId = "utterance_${System.currentTimeMillis()}"

            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}

                override fun onDone(id: String?) {
                    if (id == utteranceId) {
                        onDone()
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                    if (id == utteranceId) {
                        onDone()
                    }
                }
            })

            val params = Bundle()
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }
    }

    fun synthesizeToFile(
        text: String,
        character: Character?,
        outputFile: File,
        onComplete: (Boolean) -> Unit
    ) {
        if (!isInitialized || tts == null) {
            onComplete(false)
            return
        }

        val targetLocale = when (character?.voiceLanguage) {
            VoiceLanguage.BENGALI -> bengaliLocale
            VoiceLanguage.HINDI -> hindiLocale
            VoiceLanguage.ENGLISH -> englishLocale
            null -> englishLocale
        }

        tts?.let { engine ->
            engine.setLanguage(targetLocale)
            engine.setPitch(character?.pitch ?: 1.0f)
            engine.setSpeechRate(character?.speed ?: 1.0f)

            val utteranceId = "file_${System.currentTimeMillis()}"

            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}

                override fun onDone(id: String?) {
                    if (id == utteranceId) onComplete(true)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                    if (id == utteranceId) onComplete(false)
                }
            })

            val params = Bundle()
            engine.synthesizeToFile(text, params, outputFile, utteranceId)
        }
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}
