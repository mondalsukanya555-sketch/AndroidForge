package com.storymotion.ai.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.storymotion.ai.data.models.Character
import com.storymotion.ai.data.models.VoiceLanguage
import com.storymotion.ai.tts.StoryTtsManager
import com.storymotion.ai.ui.theme.PrimaryIndigo
import com.storymotion.ai.ui.theme.SecondaryCyan
import com.storymotion.ai.ui.theme.SurfaceCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharactersScreen(
    characters: List<Character>,
    ttsManager: StoryTtsManager,
    onAddCharacter: (Character) -> Unit,
    onUpdateCharacter: (Character) -> Unit,
    onDeleteCharacter: (String) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showDialog = true },
                containerColor = PrimaryIndigo,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = "Add") },
                text = { Text("New Character") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "Character Cast & AI Voices",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "Upload reference images, define visual traits, and set distinct voices (Bengali, Hindi, English).",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.LightGray,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            if (characters.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No characters yet. Tap + to create your first cast member!",
                        color = Color.Gray
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(characters, key = { it.id }) { character ->
                        CharacterCard(
                            character = character,
                            ttsManager = ttsManager,
                            onUpdate = onUpdateCharacter,
                            onDelete = { onDeleteCharacter(character.id) }
                        )
                    }
                }
            }
        }
    }

    if (showDialog) {
        CharacterEditDialog(
            character = null,
            onDismiss = { showDialog = false },
            onSave = { newChar ->
                onAddCharacter(newChar)
                showDialog = false
            }
        )
    }
}

@Composable
fun CharacterCard(
    character: Character,
    ttsManager: StoryTtsManager,
    onUpdate: (Character) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Character Reference Photo / Avatar
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(
                            try { Color(android.graphics.Color.parseColor(character.avatarColorHex)) }
                            catch (e: Exception) { PrimaryIndigo }
                        )
                        .border(2.dp, Color.White.copy(alpha = 0.3f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (character.imageUri != null) {
                        AsyncImage(
                            model = character.imageUri,
                            contentDescription = character.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text(
                            text = character.name.take(1),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = character.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "${character.role} • ${character.gender}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryCyan
                    )
                    Text(
                        text = "Voice: ${character.voiceLanguage.displayName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.LightGray
                    )
                }

                // Voice Test Button
                IconButton(
                    onClick = {
                        val samplePhrase = when (character.voiceLanguage) {
                            VoiceLanguage.BENGALI -> "নমস্কার! আমি ${character.name}।"
                            VoiceLanguage.HINDI -> "नमस्ते! मैं ${character.name} हूँ।"
                            VoiceLanguage.ENGLISH -> "Hello! I am ${character.name}."
                        }
                        ttsManager.speak(samplePhrase, character)
                    }
                ) {
                    Icon(
                        Icons.Default.VolumeUp,
                        contentDescription = "Test Voice",
                        tint = SecondaryCyan
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = Color(0xFFEF4444)
                    )
                }
            }

            if (character.visualTraits.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Visual Consistency: ${character.visualTraits}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharacterEditDialog(
    character: Character?,
    onDismiss: () -> Unit,
    onSave: (Character) -> Unit
) {
    var name by remember { mutableStateOf(character?.name ?: "") }
    var role by remember { mutableStateOf(character?.role ?: "") }
    var gender by remember { mutableStateOf(character?.gender ?: "male") }
    var visualTraits by remember { mutableStateOf(character?.visualTraits ?: "") }
    var selectedLanguage by remember { mutableStateOf(character?.voiceLanguage ?: VoiceLanguage.BENGALI) }
    var pitch by remember { mutableFloatStateOf(character?.pitch ?: 1.0f) }
    var speed by remember { mutableFloatStateOf(character?.speed ?: 1.0f) }
    var imageUri by remember { mutableStateOf<Uri?>(character?.imageUri) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        imageUri = uri
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (character == null) "New Character" else "Edit Character") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Upload Photo Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(Color.DarkGray)
                            .clickable { photoPickerLauncher.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        if (imageUri != null) {
                            AsyncImage(
                                model = imageUri,
                                contentDescription = "Photo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(Icons.Default.Image, contentDescription = "Pick Image", tint = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = { photoPickerLauncher.launch("image/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
                    ) {
                        Text("Upload Reference Photo")
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Character Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = role,
                    onValueChange = { role = it },
                    label = { Text("Role (Hero, Companion, Elder...)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = visualTraits,
                    onValueChange = { visualTraits = it },
                    label = { Text("Visual Consistency Traits") },
                    placeholder = { Text("e.g. Red silk scarf, silver earrings, kind eyes") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Voice Language selector
                Text("Voice Language:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VoiceLanguage.values().forEach { lang ->
                        FilterChip(
                            selected = selectedLanguage == lang,
                            onClick = { selectedLanguage = lang },
                            label = { Text(lang.name.take(2)) }
                        )
                    }
                }

                // Pitch & Speed sliders
                Text("Pitch: ${String.format("%.1f", pitch)}", style = MaterialTheme.typography.labelSmall)
                Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.6f..1.4f)

                Text("Speech Speed: ${String.format("%.1f", speed)}", style = MaterialTheme.typography.labelSmall)
                Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.7f..1.3f)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val updated = Character(
                            id = character?.id ?: "char_${System.currentTimeMillis()}",
                            name = name,
                            role = role.ifBlank { "Character" },
                            gender = gender,
                            description = visualTraits,
                            visualTraits = visualTraits,
                            imageUri = imageUri,
                            voiceLanguage = selectedLanguage,
                            pitch = pitch,
                            speed = speed
                        )
                        onSave(updated)
                    }
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
