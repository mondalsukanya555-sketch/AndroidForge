package com.storymotion.ai.data.models

import android.net.Uri

enum class VoiceLanguage(val code: String, val displayName: String) {
    BENGALI("bn", "Bengali (বাংলা)"),
    HINDI("hi", "Hindi (हिन्दी)"),
    ENGLISH("en", "English")
}

enum class CameraMotion(val displayName: String) {
    ZOOM_IN("Slow Zoom In"),
    ZOOM_OUT("Dramatic Zoom Out"),
    PAN_LEFT("Pan Left"),
    PAN_RIGHT("Pan Right"),
    STATIC("Static Framing")
}

enum class BgMusicPreset(val displayName: String) {
    BENGALI_FOLK("Bengali Folk (Ektara / Baul)"),
    INDIAN_CLASSICAL("Indian Classical (Sitar / Flute)"),
    CINEMATIC("Cinematic Orchestral"),
    UPLIFTING("Uplifting Journey"),
    NONE("No Music")
}

data class Character(
    val id: String,
    val name: String,
    val role: String,
    val gender: String, // "male", "female", "child", "other"
    val description: String,
    val visualTraits: String,
    val imageUri: Uri? = null,
    val avatarColorHex: String = "#6366f1",
    val voiceLanguage: VoiceLanguage = VoiceLanguage.BENGALI,
    val pitch: Float = 1.0f, // 0.6 to 1.4
    val speed: Float = 1.0f  // 0.8 to 1.3
)

data class DialogueLine(
    val id: String,
    val speakerId: String, // character.id or "narrator"
    val speakerName: String,
    val line: String,
    val emotion: String = "Neutral",
    val durationSec: Float = 4.0f
)

data class Scene(
    val id: String,
    val sceneNumber: Int,
    val title: String,
    val setting: String,
    val mood: String,
    val visualPrompt: String,
    val cameraMotion: CameraMotion = CameraMotion.ZOOM_IN,
    val durationSec: Float = 7.0f,
    val characterIdsPresent: List<String> = emptyList(),
    val dialogues: List<DialogueLine> = emptyList(),
    val backdropColorHex: String = "#1e1b4b"
)

data class SubtitleConfig(
    val fontSizeSp: Float = 20f,
    val textColorHex: String = "#FFFFFF",
    val backgroundColorHex: String = "#B30F172A", // 70% opacity slate
    val position: String = "BOTTOM" // "BOTTOM", "CENTER", "TOP"
)

data class StoryProject(
    val id: String,
    val title: String,
    val language: VoiceLanguage,
    val originalStory: String,
    val characters: List<Character>,
    val scenes: List<Scene>,
    val bgMusicPreset: BgMusicPreset = BgMusicPreset.BENGALI_FOLK,
    val bgMusicVolume: Float = 0.35f,
    val subtitleConfig: SubtitleConfig = SubtitleConfig(),
    val isPortrait: Boolean = false // false = 16:9, true = 9:16
)
