package com.storymotion.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DeepSlate = Color(0xFF090D16)
val SurfaceDark = Color(0xFF0F172A)
val SurfaceCard = Color(0xFF1E293B)
val PrimaryIndigo = Color(0xFF6366F1)
val SecondaryCyan = Color(0xFF38BDF8)
val AccentPink = Color(0xFFEC4899)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryIndigo,
    secondary = SecondaryCyan,
    tertiary = AccentPink,
    background = DeepSlate,
    surface = SurfaceDark,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun StoryMotionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
