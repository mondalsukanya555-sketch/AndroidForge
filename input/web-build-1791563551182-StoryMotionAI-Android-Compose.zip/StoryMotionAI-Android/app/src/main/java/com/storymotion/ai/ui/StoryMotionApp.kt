package com.storymotion.ai.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import com.storymotion.ai.audio.BgmSynthesizer
import com.storymotion.ai.data.models.*
import com.storymotion.ai.tts.StoryTtsManager
import com.storymotion.ai.ui.screens.*
import com.storymotion.ai.ui.theme.PrimaryIndigo
import com.storymotion.ai.ui.theme.SecondaryCyan
import com.storymotion.ai.ui.theme.SurfaceDark

enum class ScreenTab(val title: String) {
    CHARACTERS("Cast & Voices"),
    STORY_EDITOR("Story & Dialogue"),
    SCENES("Scenes & Motion"),
    EXPORT("Export MP4")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryMotionApp() {
    val context = LocalContext.current
    val ttsManager = remember { StoryTtsManager(context) }
    val bgmSynthesizer = remember { BgmSynthesizer() }

    DisposableEffect(Unit) {
        onDispose {
            ttsManager.shutdown()
            bgmSynthesizer.stop()
        }
    }

    var selectedTab by remember { mutableStateOf(ScreenTab.CHARACTERS) }
    var showPresetMenu by remember { mutableStateOf(false) }

    // Initial Bengali Folklore demo project
    var characters by remember {
        mutableStateOf(
            listOf(
                Character(
                    id = "char_shibu",
                    name = "শিবু মাঝি (Shibu)",
                    role = "Honest Fisherman",
                    gender = "male",
                    description = "Hardworking fisherman with sun-tanned skin",
                    visualTraits = "Brown cotton gamcha on shoulder, wooden paddle",
                    avatarColorHex = "#F97316",
                    voiceLanguage = VoiceLanguage.BENGALI,
                    pitch = 0.9f,
                    speed = 0.95f
                ),
                Character(
                    id = "char_padma",
                    name = "জলপরী পদ্মা (Padma)",
                    role = "River Spirit Guardian",
                    gender = "female",
                    description = "Ethereal water nymph with lotus garland",
                    visualTraits = "Glowing aqua skin, water lily tiara, blue silk",
                    avatarColorHex = "#06B6D4",
                    voiceLanguage = VoiceLanguage.BENGALI,
                    pitch = 1.2f,
                    speed = 1.0f
                )
            )
        )
    }

    var storyText by remember {
        mutableStateOf(
            """পদ্মা নদীর ধারে শান্ত এক জেলেপল্লি। সন্ধ্যের সোনালী আলোয় রূপোলি জলের ঢেউ খেলা করছিল।
শিবু মাঝি তার জাল গুটিয়ে বাড়ি ফেরার প্রস্তুতি নিচ্ছিল। হঠাৎ জলের গভীর থেকে একটি উজ্জ্বল আলো ভেসে উঠল।
জলপরী পদ্মা বলল: "শিবু মাঝি! ভয় পেয়ো না। আমি পদ্মা নদীর অভিভাবক। তোমার সততার জন্য নদী আজ আনন্দিত।"
শিবু হাত জোড় করে বলল: "দেবী! আমি সামান্য মাঝি। আমরা কেবল নদীর আশীর্বাদে বেঁচে থাকি।"
পদ্মা হাসিমুখে বলল: "নদীর প্রতি এই ভালোবাসা চিরকাল ধরে রেখো।"
শিবু কৃতজ্ঞ হৃদয়ে গ্রামের দিকে রওনা হল।""".trimIndent()
        )
    }

    var scenes by remember {
        mutableStateOf(
            listOf(
                Scene(
                    id = "scene_1",
                    sceneNumber = 1,
                    title = "সন্ধ্যার পদ্মা নদী",
                    setting = "Golden sunset reflecting over Padma river",
                    mood = "Serene & Warm",
                    visualPrompt = "Wide cinematic shot of Bengal river sunset, wooden boat",
                    cameraMotion = CameraMotion.PAN_RIGHT,
                    durationSec = 6.0f,
                    characterIdsPresent = listOf("char_shibu"),
                    backdropColorHex = "#EA580C",
                    dialogues = listOf(
                        DialogueLine(
                            id = "d1",
                            speakerId = "narrator",
                            speakerName = "Narrator",
                            line = "পদ্মা নদীর ধারে শান্ত এক জেলেপল্লি। সন্ধ্যের সোনালী আলোয় রূপোলি জলের ঢেউ খেলা করছিল।",
                            durationSec = 4.0f
                        )
                    )
                ),
                Scene(
                    id = "scene_2",
                    sceneNumber = 2,
                    title = "জলপরীর আবির্ভাব",
                    setting = "Glowing waters, river nymph rising",
                    mood = "Mystical & Awe-inspiring",
                    visualPrompt = "Ethereal water nymph with glowing lotus appearing before humble fisherman",
                    cameraMotion = CameraMotion.ZOOM_IN,
                    durationSec = 7.0f,
                    characterIdsPresent = listOf("char_shibu", "char_padma"),
                    backdropColorHex = "#0284C7",
                    dialogues = listOf(
                        DialogueLine(
                            id = "d2",
                            speakerId = "char_padma",
                            speakerName = "জলপরী পদ্মা",
                            line = "শিবু মাঝি! ভয় পেয়ো না। আমি পদ্মা নদীর অভিভাবক। তোমার সততার জন্য নদী আজ আনন্দিত।",
                            durationSec = 4.5f
                        ),
                        DialogueLine(
                            id = "d3",
                            speakerId = "char_shibu",
                            speakerName = "শিবু মাঝি",
                            line = "দেবী! আমি সামান্য মাঝি। আমরা কেবল নদীর আশীর্বাদে বেঁচে থাকি।",
                            durationSec = 4.0f
                        )
                    )
                )
            )
        )
    }

    var currentProject by remember {
        mutableStateOf(
            StoryProject(
                id = "proj_1",
                title = "পদ্মা নদীর রূপোলি মায়া",
                language = VoiceLanguage.BENGALI,
                originalStory = storyText,
                characters = characters,
                scenes = scenes,
                bgMusicPreset = BgMusicPreset.BENGALI_FOLK
            )
        )
    }

    // Auto-split story logic
    val autoSplitStory = {
        val paragraphs = storyText.split("\n").filter { it.isNotBlank() }
        val newScenes = paragraphs.mapIndexed { idx, p ->
            val detectedDialogues = mutableListOf<DialogueLine>()
            if (p.contains("জলপরী পদ্মা বলল:") || p.contains("পদ্মা")) {
                detectedDialogues.add(
                    DialogueLine(
                        id = "dlg_${idx}_1",
                        speakerId = "char_padma",
                        speakerName = "জলপরী পদ্মা",
                        line = p.substringAfter(":", p).trim(),
                        durationSec = 4.0f
                    )
                )
            } else if (p.contains("শিবু মাঝি") && p.contains(":")) {
                detectedDialogues.add(
                    DialogueLine(
                        id = "dlg_${idx}_2",
                        speakerId = "char_shibu",
                        speakerName = "শিবু মাঝি",
                        line = p.substringAfter(":", p).trim(),
                        durationSec = 4.0f
                    )
                )
            } else {
                detectedDialogues.add(
                    DialogueLine(
                        id = "dlg_${idx}_0",
                        speakerId = "narrator",
                        speakerName = "Narrator",
                        line = p,
                        durationSec = 4.0f
                    )
                )
            }

            Scene(
                id = "scene_gen_$idx",
                sceneNumber = idx + 1,
                title = "Beat ${idx + 1}",
                setting = "Cinematic animated landscape",
                mood = "Atmospheric",
                visualPrompt = "Digital animated matte painting, consistent characters, warm illumination",
                cameraMotion = if (idx % 2 == 0) CameraMotion.ZOOM_IN else CameraMotion.PAN_LEFT,
                durationSec = 6.0f,
                characterIdsPresent = characters.map { it.id },
                backdropColorHex = if (idx == 0) "#EA580C" else if (idx == 1) "#0284C7" else "#312E81",
                dialogues = detectedDialogues
            )
        }
        scenes = newScenes
        currentProject = currentProject.copy(scenes = newScenes, characters = characters)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "StoryMotion AI",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark),
                actions = {
                    IconButton(onClick = { showPresetMenu = true }) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "Presets", tint = SecondaryCyan)
                    }
                    DropdownMenu(
                        expanded = showPresetMenu,
                        onDismissRequest = { showPresetMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Bengali Folk: পদ্মা নদী") },
                            onClick = {
                                currentProject = currentProject.copy(language = VoiceLanguage.BENGALI, bgMusicPreset = BgMusicPreset.BENGALI_FOLK)
                                showPresetMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Hindi Fable: राजा विक्रम") },
                            onClick = {
                                storyText = "प्राचीन भारत में राजा विक्रम राज्य करते थे। एक दिन बगीचे में सुनहरी चिड़िया ने कहा: 'महाराज! सच्चा मुकुट न्याय का होता है।'"
                                currentProject = currentProject.copy(language = VoiceLanguage.HINDI, bgMusicPreset = BgMusicPreset.INDIAN_CLASSICAL)
                                autoSplitStory()
                                showPresetMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("English Sci-Fi: Sky Citadel") },
                            onClick = {
                                storyText = "High above Eldoria, Maya spun the compass. Spark beeped: 'Captain! The temporal rift is open!'"
                                currentProject = currentProject.copy(language = VoiceLanguage.ENGLISH, bgMusicPreset = BgMusicPreset.CINEMATIC)
                                autoSplitStory()
                                showPresetMenu = false
                            }
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = SurfaceDark) {
                NavigationBarItem(
                    selected = selectedTab == ScreenTab.CHARACTERS,
                    onClick = { selectedTab = ScreenTab.CHARACTERS },
                    icon = { Icon(Icons.Default.People, contentDescription = null) },
                    label = { Text(ScreenTab.CHARACTERS.title) }
                )
                NavigationBarItem(
                    selected = selectedTab == ScreenTab.STORY_EDITOR,
                    onClick = { selectedTab = ScreenTab.STORY_EDITOR },
                    icon = { Icon(Icons.Default.Edit, contentDescription = null) },
                    label = { Text(ScreenTab.STORY_EDITOR.title) }
                )
                NavigationBarItem(
                    selected = selectedTab == ScreenTab.SCENES,
                    onClick = { selectedTab = ScreenTab.SCENES },
                    icon = { Icon(Icons.Default.Movie, contentDescription = null) },
                    label = { Text(ScreenTab.SCENES.title) }
                )
                NavigationBarItem(
                    selected = selectedTab == ScreenTab.EXPORT,
                    onClick = {
                        // Sync current project before export
                        currentProject = currentProject.copy(
                            characters = characters,
                            scenes = scenes,
                            originalStory = storyText
                        )
                        selectedTab = ScreenTab.EXPORT
                    },
                    icon = { Icon(Icons.Default.VideoLibrary, contentDescription = null) },
                    label = { Text(ScreenTab.EXPORT.title) }
                )
            }
        }
    ) { paddingValues ->
        Surface(modifier = Modifier.padding(paddingValues)) {
            when (selectedTab) {
                ScreenTab.CHARACTERS -> {
                    CharactersScreen(
                        characters = characters,
                        ttsManager = ttsManager,
                        onAddCharacter = { characters = characters + it },
                        onUpdateCharacter = { updated ->
                            characters = characters.map { if (it.id == updated.id) updated else it }
                        },
                        onDeleteCharacter = { id ->
                            characters = characters.filterNot { it.id == id }
                        }
                    )
                }
                ScreenTab.STORY_EDITOR -> {
                    StoryEditorScreen(
                        storyText = storyText,
                        onStoryTextChange = { storyText = it },
                        characters = characters,
                        scenes = scenes,
                        onAutoSplitStory = autoSplitStory,
                        onUpdateDialogueSpeaker = { sIdx, dIdx, speakerId, speakerName ->
                            val updatedScenes = scenes.toMutableList()
                            val scene = updatedScenes[sIdx]
                            val dialogues = scene.dialogues.toMutableList()
                            dialogues[dIdx] = dialogues[dIdx].copy(speakerId = speakerId, speakerName = speakerName)
                            updatedScenes[sIdx] = scene.copy(dialogues = dialogues)
                            scenes = updatedScenes
                        },
                        ttsManager = ttsManager
                    )
                }
                ScreenTab.SCENES -> {
                    SceneTimelineScreen(
                        scenes = scenes,
                        characters = characters,
                        onUpdateScene = { idx, updatedScene ->
                            val updated = scenes.toMutableList()
                            updated[idx] = updatedScene
                            scenes = updated
                        }
                    )
                }
                ScreenTab.EXPORT -> {
                    VideoExportScreen(
                        project = currentProject.copy(characters = characters, scenes = scenes),
                        ttsManager = ttsManager,
                        bgmSynthesizer = bgmSynthesizer,
                        onUpdateProject = { currentProject = it }
                    )
                }
            }
        }
    }
}
