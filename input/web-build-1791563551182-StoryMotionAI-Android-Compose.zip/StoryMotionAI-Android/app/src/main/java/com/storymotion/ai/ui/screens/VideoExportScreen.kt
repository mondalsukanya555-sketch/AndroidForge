package com.storymotion.ai.ui.screens

import android.content.Intent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.storymotion.ai.audio.BgmSynthesizer
import com.storymotion.ai.data.models.BgMusicPreset
import com.storymotion.ai.data.models.CameraMotion
import com.storymotion.ai.data.models.StoryProject
import com.storymotion.ai.tts.StoryTtsManager
import com.storymotion.ai.ui.theme.PrimaryIndigo
import com.storymotion.ai.ui.theme.SecondaryCyan
import com.storymotion.ai.ui.theme.SurfaceCard
import com.storymotion.ai.video.Mp4VideoExporter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun VideoExportScreen(
    project: StoryProject,
    ttsManager: StoryTtsManager,
    bgmSynthesizer: BgmSynthesizer,
    onUpdateProject: (StoryProject) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val exporter = remember { Mp4VideoExporter(context) }

    var isPlaying by remember { mutableStateOf(false) }
    var currentSceneIndex by remember { mutableStateOf(0) }
    var currentDialogueIndex by remember { mutableStateOf(0) }

    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableIntStateOf(0) }
    var exportStatus by remember { mutableStateOf("") }
    var exportedFile by remember { mutableStateOf<File?>(null) }

    // Live Playback Engine
    LaunchedEffect(isPlaying) {
        if (isPlaying && project.scenes.isNotEmpty()) {
            bgmSynthesizer.start(project.bgMusicPreset, project.bgMusicVolume)

            for (sIdx in project.scenes.indices) {
                if (!isPlaying) break
                currentSceneIndex = sIdx
                val scene = project.scenes[sIdx]

                for (dIdx in scene.dialogues.indices) {
                    if (!isPlaying) break
                    currentDialogueIndex = dIdx
                    val dialogue = scene.dialogues[dIdx]

                    val speakerChar = project.characters.find { it.id == dialogue.speakerId }

                    // Trigger Voice synthesis
                    var doneSpeaking = false
                    ttsManager.speak(dialogue.line, speakerChar) {
                        doneSpeaking = true
                    }

                    val timeout = (dialogue.durationSec * 1000).toLong()
                    val startTime = System.currentTimeMillis()
                    while (!doneSpeaking && (System.currentTimeMillis() - startTime) < timeout && isPlaying) {
                        delay(50)
                    }
                    delay(300)
                }
            }
            isPlaying = false
            bgmSynthesizer.stop()
        } else {
            bgmSynthesizer.stop()
            ttsManager.stop()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Video Preview & MP4 Exporter",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // Video Player Frame
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
        ) {
            val activeScene = project.scenes.getOrNull(currentSceneIndex)
            val activeDialogue = activeScene?.dialogues?.getOrNull(currentDialogueIndex)

            Box(modifier = Modifier.fillMaxSize()) {
                // Animated Canvas Canvas
                val animatedProgress by animateFloatAsState(
                    targetValue = if (isPlaying) 1f else 0f,
                    animationSpec = tween(durationMillis = 6000),
                    label = "motion"
                )

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // 1. Draw Environmental Gradient
                    val baseColor = try {
                        Color(android.graphics.Color.parseColor(activeScene?.backdropColorHex ?: "#1e1b4b"))
                    } catch (e: Exception) { Color(0xFF1E1B4B) }

                    drawRect(color = baseColor, size = size)

                    // 2. Camera Motion Simulation
                    val motion = activeScene?.cameraMotion ?: CameraMotion.ZOOM_IN
                    val scaleFactor = when (motion) {
                        CameraMotion.ZOOM_IN -> 1.0f + animatedProgress * 0.12f
                        CameraMotion.ZOOM_OUT -> 1.12f - animatedProgress * 0.12f
                        else -> 1.04f
                    }

                    scale(scaleFactor, pivot = Offset(w / 2, h / 2)) {
                        // Distant horizon wave
                        drawRect(
                            color = Color(0x330F172A),
                            topLeft = Offset(0f, h * 0.65f),
                            size = Size(w, h * 0.35f)
                        )

                        // Draw Character Avatars
                        val present = project.characters.filter { activeScene?.characterIdsPresent?.contains(it.id) == true }
                        val count = present.size

                        present.forEachIndexed { idx, char ->
                            val posX = if (count == 1) w * 0.5f else if (idx == 0) w * 0.3f else w * 0.7f
                            val posY = h * 0.5f

                            val isSpeaking = activeDialogue?.speakerId == char.id
                            val avatarColor = try {
                                Color(android.graphics.Color.parseColor(char.avatarColorHex))
                            } catch (e: Exception) { PrimaryIndigo }

                            if (isSpeaking) {
                                drawCircle(color = avatarColor.copy(alpha = 0.4f), radius = 42f, center = Offset(posX, posY))
                            }
                            drawCircle(color = avatarColor, radius = 30f, center = Offset(posX, posY))
                        }
                    }
                }

                // Subtitle Overlay
                if (activeDialogue != null) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(12.dp)
                            .background(Color(0xD90F172A), RoundedCornerShape(12.dp))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${activeDialogue.speakerName}:",
                                style = MaterialTheme.typography.labelSmall,
                                color = SecondaryCyan,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = activeDialogue.line,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        // Play / Stop Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { isPlaying = !isPlaying },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = if (isPlaying) Color(0xFFEF4444) else PrimaryIndigo)
            ) {
                Icon(if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isPlaying) "Stop Preview" else "Play Story Preview")
            }
        }

        // Background Music Presets
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Soundtrack & Background Music:", style = MaterialTheme.typography.titleSmall, color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BgMusicPreset.values().take(3).forEach { preset ->
                        FilterChip(
                            selected = project.bgMusicPreset == preset,
                            onClick = { onUpdateProject(project.copy(bgMusicPreset = preset)) },
                            label = { Text(preset.displayName.take(12)) }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Export MP4 Button
        Button(
            onClick = {
                isExporting = true
                coroutineScope.launch {
                    val result = exporter.exportProjectToMp4(project) { percent, status ->
                        exportProgress = percent
                        exportStatus = status
                    }
                    isExporting = false
                    if (result.isSuccess) {
                        exportedFile = result.getOrNull()
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SecondaryCyan)
        ) {
            Icon(Icons.Default.FileDownload, contentDescription = null, tint = Color.Black)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Export Final MP4 Video", color = Color.Black, fontWeight = FontWeight.Bold)
        }

        // Share exported file if ready
        exportedFile?.let { file ->
            OutlinedButton(
                onClick = {
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share StoryMotion Video"))
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Share ${file.name}")
            }
        }
    }

    // Export Progress Dialog
    if (isExporting) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Rendering Native MP4 Video") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    LinearProgressIndicator(
                        progress = { exportProgress / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("$exportProgress% — $exportStatus", style = MaterialTheme.typography.bodyMedium)
                }
            },
            confirmButton = {}
        )
    }
}
