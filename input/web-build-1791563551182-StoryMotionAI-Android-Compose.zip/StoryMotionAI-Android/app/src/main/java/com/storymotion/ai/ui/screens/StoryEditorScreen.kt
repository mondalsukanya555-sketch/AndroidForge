package com.storymotion.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.storymotion.ai.data.models.*
import com.storymotion.ai.tts.StoryTtsManager
import com.storymotion.ai.ui.theme.PrimaryIndigo
import com.storymotion.ai.ui.theme.SecondaryCyan
import com.storymotion.ai.ui.theme.SurfaceCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryEditorScreen(
    storyText: String,
    onStoryTextChange: (String) -> Unit,
    characters: List<Character>,
    scenes: List<Scene>,
    onAutoSplitStory: () -> Unit,
    onUpdateDialogueSpeaker: (sceneIndex: Int, dialogueIndex: Int, newSpeakerId: String, newSpeakerName: String) -> Unit,
    ttsManager: StoryTtsManager
) {
    var selectedLanguage by remember { mutableStateOf(VoiceLanguage.BENGALI) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Story Script & Dialogue Director",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "Write or paste your story in Bengali, Hindi, or English. Assign lines to specific character voices.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.LightGray
        )

        // Story input card
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = storyText,
                    onValueChange = onStoryTextChange,
                    label = { Text("Story Narrative") },
                    placeholder = { Text("Paste your full narrative here...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoiceLanguage.values().forEach { lang ->
                            FilterChip(
                                selected = selectedLanguage == lang,
                                onClick = { selectedLanguage = lang },
                                label = { Text(lang.displayName.take(7)) }
                            )
                        }
                    }

                    Button(
                        onClick = onAutoSplitStory,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Auto-Split Scenes")
                    }
                }
            }
        }

        // Assigned Dialogues Header
        Text(
            text = "Assigned Dialogues & Voices (${scenes.sumOf { it.dialogues.size }})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        if (scenes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Tap 'Auto-Split Scenes' above to generate dialogue lines and scene beats.",
                    color = Color.Gray
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                scenes.forEachIndexed { sIdx, scene ->
                    item {
                        Text(
                            text = "Scene ${scene.sceneNumber}: ${scene.title}",
                            style = MaterialTheme.typography.labelLarge,
                            color = SecondaryCyan,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    itemsIndexed(scene.dialogues) { dIdx, dialogue ->
                        DialogueRow(
                            dialogue = dialogue,
                            characters = characters,
                            onSpeakerChange = { speakerId, speakerName ->
                                onUpdateDialogueSpeaker(sIdx, dIdx, speakerId, speakerName)
                            },
                            onTestVoice = {
                                val speaker = characters.find { it.id == dialogue.speakerId }
                                ttsManager.speak(dialogue.line, speaker)
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DialogueRow(
    dialogue: DialogueLine,
    characters: List<Character>,
    onSpeakerChange: (String, String) -> Unit,
    onTestVoice: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard.copy(alpha = 0.7f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Speaker selection chip
            Box {
                OutlinedButton(
                    onClick = { expanded = true },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = dialogue.speakerName.take(12),
                        color = SecondaryCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    DropdownMenuItem(
                        text = { Text("Narrator") },
                        onClick = {
                            onSpeakerChange("narrator", "Narrator")
                            expanded = false
                        }
                    )
                    characters.forEach { char ->
                        DropdownMenuItem(
                            text = { Text("${char.name} (${char.role})") },
                            onClick = {
                                onSpeakerChange(char.id, char.name)
                                expanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Line text
            Text(
                text = "\"${dialogue.line}\"",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
                modifier = Modifier.weight(1f)
            )

            // Audition speech
            IconButton(onClick = onTestVoice) {
                Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = "Audition Voice",
                    tint = SecondaryCyan
                )
            }
        }
    }
}
