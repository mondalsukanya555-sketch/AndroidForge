package com.storymotion.ai.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.storymotion.ai.data.models.BgMusicPreset
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin

class BgmSynthesizer {

    private var audioTrack: AudioTrack? = null
    private var isPlaying = false
    private var synthThread: Thread? = null
    private var currentVolume = 0.35f

    fun start(preset: BgMusicPreset, volume: Float = 0.35f) {
        if (preset == BgMusicPreset.NONE) {
            stop()
            return
        }
        stop()

        currentVolume = volume
        isPlaying = true

        val sampleRate = 44100
        val bufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ) * 2

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.setVolume(currentVolume)
        audioTrack?.play()

        synthThread = thread(start = true) {
            val shortBuffer = ShortArray(bufferSize / 2)
            var sampleIndex = 0L

            // Harmonic frequencies based on preset
            val freqs = when (preset) {
                BgMusicPreset.BENGALI_FOLK -> doubleArrayOf(185.0, 277.18, 369.99) // F# & C# Drone
                BgMusicPreset.INDIAN_CLASSICAL -> doubleArrayOf(146.83, 220.0, 293.66) // D & A Tanpura
                BgMusicPreset.CINEMATIC -> doubleArrayOf(220.0, 261.63, 329.63) // A minor strings
                BgMusicPreset.UPLIFTING -> doubleArrayOf(293.66, 369.99, 440.0) // D major acoustic
                BgMusicPreset.NONE -> doubleArrayOf(0.0)
            }

            while (isPlaying) {
                for (i in shortBuffer.indices) {
                    val t = sampleIndex.toDouble() / sampleRate
                    var sampleVal = 0.0

                    // Wave composition
                    for (f in freqs) {
                        sampleVal += sin(2.0 * PI * f * t) * 0.3
                    }
                    // Gentle amplitude pulse (4 second period)
                    val pulse = 0.6 + 0.4 * sin(2.0 * PI * 0.25 * t)
                    val finalSample = (sampleVal * pulse * 32767.0 * 0.4).toInt()

                    shortBuffer[i] = finalSample.coerceIn(-32767, 32767).toShort()
                    sampleIndex++
                }

                audioTrack?.write(shortBuffer, 0, shortBuffer.size)
            }
        }
    }

    fun setVolume(volume: Float) {
        currentVolume = volume
        audioTrack?.setVolume(currentVolume)
    }

    fun stop() {
        isPlaying = false
        synthThread?.interrupt()
        synthThread = null

        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
    }
}
