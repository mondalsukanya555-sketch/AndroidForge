package com.storymotion.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.storymotion.ai.ui.StoryMotionApp
import com.storymotion.ai.ui.theme.StoryMotionTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StoryMotionTheme {
                StoryMotionApp()
            }
        }
    }
}
