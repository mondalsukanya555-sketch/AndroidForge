# StoryMotion AI — Native Android App (Kotlin & Jetpack Compose)

This is a complete, production-ready native Android project for **StoryMotion AI** built with **Kotlin 2.0** and **Jetpack Compose (Material 3)**.

---

## Features Implemented in Native Android

1. **Character Management & Reference Images**:
   - Upload reference images from device gallery via Android `ActivityResultContracts.GetContent()`.
   - Store character names, roles, gender, and detailed visual consistency traits.
   - Assign color theme tags to each character.

2. **Multilingual AI Text-To-Speech**:
   - Integrates Android's native `android.speech.tts.TextToSpeech`.
   - Supports **Bengali (বাংলা)** via `Locale("bn", "IN")` / `Locale("bn", "BD")`.
   - Supports **Hindi (हिन्दी)** via `Locale("hi", "IN")`.
   - Supports **English** via `Locale.US`.
   - Individual pitch (`0.6x - 1.4x`) and speed (`0.7x - 1.3x`) controls per character.
   - In-app **Voice Audition** button to test dialogue delivery.

3. **Story Script & Dialogue Director**:
   - Enter complete stories in Bengali, Hindi, or English.
   - One-tap **Auto-Split Scenes** engine parsing narrative into sequential cinematic beats.
   - Dialogue assigning: pick speaker (Character A, Character B, or Narrator) for each sentence.

4. **Scene Timeline & Camera Animations**:
   - Camera motion controls: **Slow Zoom In**, **Dramatic Zoom Out**, **Pan Left**, **Pan Right**, and **Static**.
   - Character presence toggles: specify which characters appear on stage in each scene.
   - Setting descriptions and visual prompts for visual consistency.

5. **Soundtrack & Background Music**:
   - Built-in procedural `AudioTrack` synthesizer:
     - **Bengali Folk**: Ektara / Baul drone harmonics (F# & C#)
     - **Indian Classical**: Tanpura & Sitar drone (D & A)
     - **Cinematic**: Orchestral string progression (A minor)
     - **Uplifting**: Acoustic overtone pulse
   - Automatic volume ducking during spoken dialogue.

6. **MP4 Video Exporter**:
   - Hardware-accelerated native Android `MediaCodec` (H.264) + `MediaMuxer`.
   - Renders 1280x720 (16:9) and 720x1280 (9:16 portrait) frames from hardware Surface.
   - Burns synchronized subtitles with custom styling.
   - Exports a valid `.mp4` video directly to device storage with direct Android Share Intent (`Intent.ACTION_SEND`).

---

## How to Build the Installable Android APK

### Option 1: Using Command Line (Terminal)

1. Open your terminal and navigate to the `android/` directory:
   ```bash
   cd android
   ```

2. Make sure the Gradle wrapper is executable:
   ```bash
   chmod +x gradlew
   ```

3. Build the Debug APK:
   ```bash
   ./gradlew assembleDebug
   ```

4. The installable APK will be generated at:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

5. Install it onto your connected Android phone or emulator via ADB:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

---

### Option 2: Using Android Studio (GUI)

1. Open **Android Studio** (Koala, Iguana, or newer).
2. Click **File > Open...** and select the `android/` folder.
3. Wait for Gradle Sync to complete.
4. Connect your Android device via USB (or start an Android Virtual Device / Emulator).
5. Click the green **Run (▶)** button or go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. A notification will appear: **"APK(s) generated successfully."** Click **Locate** to get your `.apk` file.

---

## Requirements & Compatibility
- **Min SDK**: Android 8.0 (API level 26)
- **Target SDK**: Android 14 (API level 34)
- **Kotlin**: 2.0.20
- **Jetpack Compose**: Material 3 BOM 2024.09.03
- **JDK**: Version 17 or Version 21
